package hello.hellospring.repository;

import hello.hellospring.domain.Account;

public interface AccountRepository {

    Account NowState(Account account);
    Account Create(Account account);

    Account Deposit(Account account);

    Account Withdraw(Account account);

//    Account Change(Account account);

    Account ListStore();
}
