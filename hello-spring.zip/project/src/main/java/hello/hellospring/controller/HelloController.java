package hello.hellospring.controller;

import hello.hellospring.domain.Account;
import hello.hellospring.repository.MemoryAccountRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class HelloController {

    Account account = new Account();
    MemoryAccountRepository memoryAccountRepository = new MemoryAccountRepository();


    @GetMapping("test")
    @ResponseBody
    public Account test(@RequestParam("accountName") String accountName ) {
        account.setaccountName(accountName);
        return memoryAccountRepository.NowState(account);
    }

    @GetMapping("create")
    @ResponseBody
    public Account create(@RequestParam("accountName") String accountName) {
        account.setaccountName(accountName);
        return memoryAccountRepository.Create(account);
    }

    @GetMapping("deposit")
    @ResponseBody
    public Account deposit(@RequestParam("accountName") String accountName,@RequestParam("addBalance") int nowBalance ) {
        account.setaccountName(accountName);
        account.setNowBalance(nowBalance);
        return memoryAccountRepository.Deposit(account);
    }

    @GetMapping("withdraw")
    @ResponseBody
    public Account withdraw(@RequestParam("accountName") String accountName,@RequestParam("delBalance") int nowBalance ) {
        account.setaccountName(accountName);
        account.setNowBalance(nowBalance);
        return memoryAccountRepository.Deposit(account);
    }








    static class Hello {
        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        private String name;

    }
}
